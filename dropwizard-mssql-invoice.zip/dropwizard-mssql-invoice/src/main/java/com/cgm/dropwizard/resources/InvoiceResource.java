package com.cgm.dropwizard.resources;

import static com.cgm.dropwizard.resources.ResourcesConstants.PATH_INVOICE;

import java.net.URI;
import java.net.URISyntaxException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import com.cgm.dropwizard.core.Invoice;
import com.cgm.dropwizard.db.InvoiceDAO;
import com.cgm.dropwizard.views.InvoiceView;

import io.dropwizard.hibernate.UnitOfWork;


/**
 * @author lij
 */
@Path(PATH_INVOICE)
public class InvoiceResource {
	
	private InvoiceDAO invoiceDAO;
	
	public InvoiceResource(InvoiceDAO invoiceDAO) {
		this.invoiceDAO = invoiceDAO;
	}
	
	@GET
	@UnitOfWork
	@Produces(MediaType.TEXT_HTML)
	public InvoiceView getInvoices() {
		return new InvoiceView(invoiceDAO.findAll());
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	@UnitOfWork
	@Path("/{id}")
	public InvoiceView getInvoice(@PathParam("id") Long id) {
		return new InvoiceView(invoiceDAO.findById(id));
	}

	@PUT
	@Produces(MediaType.TEXT_HTML)
	@UnitOfWork
	@Path("/update/{id}")
	public Response update(@PathParam(Invoice.PROPERTY_ID) Long id) {
		InvoiceView view = new InvoiceView(InvoiceView.TEMPLATE_NAME_INVOICE_UPDATE);
		invoiceDAO.update(id, view.getInvoice());
		URI location = UriBuilder.fromUri("/invoices").build();
		return Response.seeOther(location).build();
	}

	@GET
	@Produces(MediaType.TEXT_HTML)
	@UnitOfWork
	@Path("/new")
	public InvoiceView create() {
		return new InvoiceView(InvoiceView.TEMPLATE_NAME_INVOICE_CREATE);
	}

	@GET
	@Produces(MediaType.TEXT_HTML)
	@UnitOfWork
	@Path("/update")
	public InvoiceView update() {
		return new InvoiceView(InvoiceView.TEMPLATE_NAME_INVOICE_UPDATE);
	}

	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@UnitOfWork
	public Response save(
			@FormParam(Invoice.PROPERTY_NAME) String name,
			@FormParam(Invoice.PROPERTY_DOCTOR) String doctor,
			@FormParam(Invoice.PROPERTY_AMOUNT) Integer amount,
			@FormParam(Invoice.PROPERTY_RECIPIENT_NAME) String recipientName,
			@FormParam(Invoice.PROPERTY_DOCUMENTS) String documentsJson
			) throws URISyntaxException {

		// TODO Documets

		Invoice newInvoice = new Invoice(name,doctor, amount, recipientName);
		newInvoice = invoiceDAO.create(newInvoice);
		URI location = UriBuilder.fromUri("/invoices").build();
		return Response.seeOther(location).build();
	}

	@DELETE
	@Path("/{id}")
	@UnitOfWork
	public Response delete(@PathParam(Invoice.PROPERTY_ID) Long id) {
		invoiceDAO.delete(id);
		URI location = UriBuilder.fromUri("/invoices").build();
		return Response.seeOther(location).build();
	}
}
