package com.cgm.dropwizard.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

/**
 * @author lij
 */
@Entity
@Table(name = "invoice")
public class Invoice implements Serializable {
	
	private static final long serialVersionUID = -4805124311615672037L;
	public static final String PROPERTY_ID = "id";
	public static final String PROPERTY_NAME = "name";
	public static final String PROPERTY_DOCTOR = "doctor";
	public static final String PROPERTY_AMOUNT = "amount";
	public static final String PROPERTY_RECIPIENT_NAME = "recipient.name";
	public static final String PROPERTY_DOCUMENTS = "documents";

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	private String name;

	private String doctor;

	private Integer amount;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Recipient recipient;

	@OneToMany(
			mappedBy = "invoice",
			cascade = CascadeType.ALL,
			orphanRemoval = true
	)
	private List<Document> documents = new ArrayList<>();

	public Invoice() {}
	
	public Invoice(String name, String doctor, Integer amount, Recipient recipient) {
		this.name = name;
		this.doctor = doctor;
		this.amount = amount;
		this.recipient = recipient;
	}

	public Invoice(String name, String doctor, Integer amount, String recipientName) {
		this.name = name;
		this.doctor = doctor;
		this.amount = amount;
		// TODO RecipientHealth
		RecipientHealth health = RecipientHealth.randomHealth();
		Recipient recipient = new Recipient(this, recipientName, health);
		this.recipient = recipient;
	}

	public Invoice(String name, String doctor, Integer amount, String recipientName,
				   List<Document> documents) {
		this.name= name;
		this.doctor = doctor;
		this.amount = amount;
		// TODO RecipientHealth
		RecipientHealth health = RecipientHealth.randomHealth();
		Recipient recipient = new Recipient(this, recipientName, health);
		this.recipient = recipient;
		this.documents = documents;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public Recipient getRecipient() {
		return recipient;
	}

	public void setRecipient(Recipient recipient) {
		this.recipient = recipient;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}
}
