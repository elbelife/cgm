package com.cgm.dropwizard.views;

import java.util.List;

import com.cgm.dropwizard.core.Invoice;

import io.dropwizard.views.View;

/**
 * @author lij
 */
public class InvoiceView extends View {
	
	public static final String TEMPLATE_NAME_INVOICE_VIEW = "invoice/InvoiceView.ftl";
	public static final String TEMPLATE_NAME_INVOICES_VIEW = "invoice/InvoicesView.ftl";
	public static final String TEMPLATE_NAME_INVOICE_CREATE = "invoice/CreateInvoiceView.ftl";
	public static final String TEMPLATE_NAME_INVOICE_UPDATE= "invoice/UpdateInvoiceView.ftl";
	
	private Invoice invoice;
	
	private List<Invoice> invoices;
	
	public InvoiceView(String templateName) {
		super(templateName);
	}

	public InvoiceView(Invoice invoice) {
		super(TEMPLATE_NAME_INVOICE_VIEW);
		this.invoice = invoice;
	}
	
	public InvoiceView(List<Invoice> invoices) {
		super(TEMPLATE_NAME_INVOICES_VIEW);
		this.invoices = invoices;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public List<Invoice> getInvoices() {
		return invoices;
	}

	public void setInvoices(List<Invoice> invoices) {
		this.invoices = invoices;
	}

}
