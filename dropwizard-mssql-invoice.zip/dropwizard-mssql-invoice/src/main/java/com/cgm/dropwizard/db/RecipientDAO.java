package com.cgm.dropwizard.db;

import org.hibernate.SessionFactory;

import com.cgm.dropwizard.core.Recipient;

import io.dropwizard.hibernate.AbstractDAO;

/**
 * @author lij
 */
public class RecipientDAO extends AbstractDAO<Recipient> {

	public RecipientDAO(SessionFactory sessionFactory) {
		super(sessionFactory);
	}

}
