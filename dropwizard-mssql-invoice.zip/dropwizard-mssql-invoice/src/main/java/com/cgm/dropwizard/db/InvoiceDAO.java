package com.cgm.dropwizard.db;

import java.io.IOException;
import java.util.List;

import com.cgm.dropwizard.core.Document;
import com.cgm.dropwizard.core.Invoice;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hibernate.SessionFactory;

import io.dropwizard.hibernate.AbstractDAO;

import javax.ws.rs.NotFoundException;

/**
 * @author lij
 */
public class InvoiceDAO extends AbstractDAO<Invoice> {
	
	public InvoiceDAO(SessionFactory sessionFactory) {
		super(sessionFactory);
	}
	
	public Invoice findById(Long id) {
		return get(id);
	}
	
	public Invoice update(Long id, Invoice invoice) {
		//TODO hier kann mann Invoicewarped überlegen
		Invoice newInvoice = findById(id);
		newInvoice.setAmount(invoice.getAmount());
		newInvoice.setRecipient(invoice.getRecipient());
		newInvoice.setDoctor(invoice.getDoctor());
		newInvoice.setName(invoice.getName());
		newInvoice.setDocuments(invoice.getDocuments());
		return persist(newInvoice);
	}

	public Invoice create(Invoice invoice) {
		return persist(invoice);
	}
	
	public List<Invoice> findAll() {
		return list(criteria());
	}
	
	public void delete(Long id) {
		Invoice invoice = findById(id);
		currentSession().delete(invoice);
	}

	public List<Document> JsonToDocuments(String json){
		ObjectMapper mapper = new ObjectMapper();
		try {
			List<Document> documents = mapper.readValue(json,
					mapper.getTypeFactory().constructCollectionType(List.class, Document.class));
			return documents;
		} catch (IOException e) {
			throw new NotFoundException();
		}
	}
}
