package com.cgm.dropwizard;

import com.cgm.dropwizard.core.Document;
import com.cgm.dropwizard.core.Invoice;
import com.cgm.dropwizard.core.Recipient;
import com.cgm.dropwizard.db.InvoiceDAO;
import com.cgm.dropwizard.resources.InvoiceResource;

import io.dropwizard.Application;
import io.dropwizard.assets.AssetsBundle;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.hibernate.HibernateBundle;
import io.dropwizard.migrations.MigrationsBundle;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import io.dropwizard.views.ViewBundle;

/**
 * @author lij
 */
public class DropwizardInvoiceApplication extends Application<DropwizardInvoiceConfiguration> {

	public static final String APPLICATION_NAME = "DropwizardInvoiceApp";

	public static void main(final String[] args) throws Exception {
		new DropwizardInvoiceApplication().run(args);
	}

	// Hibernate
	private final HibernateBundle<DropwizardInvoiceConfiguration> hibernate = new HibernateBundle<DropwizardInvoiceConfiguration>(
			Document.class,
			Invoice.class,
			Recipient.class) {
		@Override
		public DataSourceFactory getDataSourceFactory(DropwizardInvoiceConfiguration configuration) {
			return configuration.getDatabase();
		}
	};
	
	private final MigrationsBundle<DropwizardInvoiceConfiguration> migrations = new MigrationsBundle<DropwizardInvoiceConfiguration>() {
		@Override
		public DataSourceFactory getDataSourceFactory(DropwizardInvoiceConfiguration configuration) {
			return configuration.getDatabase();
		}
	};

	@Override
	public String getName() {
		return APPLICATION_NAME;
	}

	@Override
	public void initialize(final Bootstrap<DropwizardInvoiceConfiguration> bootstrap) {
		bootstrap.addBundle(hibernate);
		bootstrap.addBundle(new ViewBundle<DropwizardInvoiceConfiguration>());
		bootstrap.addBundle(migrations);
		bootstrap.addBundle(new AssetsBundle("/assets/"));
	}

	@Override
	public void run(final DropwizardInvoiceConfiguration configuration, final Environment environment) {
		final InvoiceDAO invoiceDAO = new InvoiceDAO(hibernate.getSessionFactory());
		environment.jersey().register(new InvoiceResource(invoiceDAO));
	}
}
