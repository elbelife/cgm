package com.cgm.dropwizard.resources;

/**
 * @author lij
 */
public class ResourcesConstants {
	
	public static final String PATH_INVOICE = "/invoices";
	
	public static final String VIEWS_MEDIA_TYPE_HTML_UTF8 = "text/html;charset=UTF-8";

}
