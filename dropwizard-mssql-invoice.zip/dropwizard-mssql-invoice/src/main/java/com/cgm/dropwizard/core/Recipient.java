package com.cgm.dropwizard.core;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 * @author lij
 */
@Entity
public class Recipient implements Serializable {
	
	private static final long serialVersionUID = -5518754465087748141L;
	
	@Id
	@GeneratedValue
	private Long id;
	
	@OneToOne(mappedBy = "recipient")
	private Invoice invoice;
	
	private String name;
	
	@Enumerated
	private RecipientHealth health;
	
	public Recipient() {}
	
	public Recipient(Invoice invoice, String name, RecipientHealth health) {
		this.invoice = invoice;
		this.name = name;
		this.health = health;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public RecipientHealth getHealth() {
		return health;
	}

	public void setHealth(RecipientHealth health) {
		this.health = health;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
