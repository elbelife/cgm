package com.cgm.dropwizard.db;

import com.cgm.dropwizard.core.Document;
import com.cgm.dropwizard.core.Invoice;
import com.cgm.dropwizard.core.Recipient;
import com.cgm.dropwizard.core.RecipientHealth;
import io.dropwizard.testing.junit5.DAOTestExtension;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Unit tests for {@link InvoiceDAO}.
 */
@ExtendWith(DropwizardExtensionsSupport.class)
class InvoiceDAOTest {
    public DAOTestExtension daoTestRule = DAOTestExtension.newBuilder()
            .addEntityClass(Invoice.class)
            .addEntityClass(Recipient.class)
            .addEntityClass(Document.class)
            .build();

    private InvoiceDAO invoiceDAO;

    @BeforeEach
    public void setUp() throws Exception {
        invoiceDAO = new InvoiceDAO(daoTestRule.getSessionFactory());
    }

    @Test
    void findById() {
        Invoice invoice = new Invoice("name", "doctor", 1, "recipientName");
        daoTestRule.inTransaction(() -> {
            invoiceDAO.create(invoice);
        });
        assertThat(invoiceDAO.findById(invoice.getId())).isNotNull();
        assertThat(invoiceDAO.findById(invoice.getId())).isEqualTo(invoice);
    }

    @Test
    void create() {

        final Invoice invoice = daoTestRule.inTransaction(() ->
                invoiceDAO.create(new Invoice("name", "doctor", 1, "recipientName" )));
        assertThat(invoice.getId()).isGreaterThan(0);
        assertThat(invoice.getName()).isEqualTo("name");
        assertThat(invoice.getDoctor()).isEqualTo("doctor");
        assertThat(invoice.getAmount()).isEqualTo(1);
        assertThat(invoice.getRecipient()).isExactlyInstanceOf(Recipient.class);
        assertThat(invoiceDAO.findById(invoice.getId())).isEqualTo(invoice);
    }

    @Test
    void findAll() {
        Recipient mockRecipient1 = mock(Recipient.class);
        mockRecipient1.setName("RN1");
        Recipient mockRecipient2 = mock(Recipient.class);
        mockRecipient2.setName("RN2");
        Recipient mockRecipient3 = mock(Recipient.class);
        mockRecipient3.setName("RN3");
        daoTestRule.inTransaction(() -> {
            invoiceDAO.create(new Invoice("N1", "D1", 1, mockRecipient1));
            invoiceDAO.create(new Invoice("N2", "D2", 2, mockRecipient2));
            invoiceDAO.create(new Invoice("N3", "D3", 3, mockRecipient3));
        });

        final List<Invoice> invoices = invoiceDAO.findAll();
        assertThat(invoices).size().isEqualTo(3);
        assertThat(invoices).extracting("name").containsOnly("N1", "N2", "N3");
        assertThat(invoices).extracting("doctor").containsOnly("D1", "D2", "D3");
        assertThat(invoices).extracting("recipient").containsOnly(mockRecipient1, mockRecipient2, mockRecipient3);
    }

    @Test
    void delete() {
        Invoice invoice = daoTestRule.inTransaction(() ->
                invoiceDAO.create(new Invoice("name", "doctor", 1, "recipientName")));
        invoiceDAO.delete(invoice.getId());
        assertThat(invoiceDAO.findById(invoice.getId())).isNull();
    }

    private Recipient initRecipient(Invoice invoice){
        Recipient recipient = new Recipient(
                invoice,
                "recipientName",
                RecipientHealth.EXCELENT
        );
        return  recipient;
    }
}