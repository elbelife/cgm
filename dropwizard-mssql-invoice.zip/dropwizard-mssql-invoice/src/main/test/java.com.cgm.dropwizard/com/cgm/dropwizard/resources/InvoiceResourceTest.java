package com.cgm.dropwizard.resources;

import com.cgm.dropwizard.core.Invoice;
import com.cgm.dropwizard.core.Recipient;
import com.cgm.dropwizard.core.RecipientHealth;
import com.cgm.dropwizard.db.InvoiceDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link InvoiceResource}.
 */
@ExtendWith(DropwizardExtensionsSupport.class)
class InvoiceResourceTest {

    private static final InvoiceDAO INVOICE_DAO = mock(InvoiceDAO.class);
    public static final ResourceExtension RESOURCES = ResourceExtension.builder()
            .addResource(new InvoiceResource(INVOICE_DAO))
            .build();
    private ArgumentCaptor<Invoice> personCaptor = ArgumentCaptor.forClass(Invoice.class);
    private Invoice invoice;

    @BeforeEach
    public void setUp() {
        invoice = new Invoice();
        invoice.setId(1L);
        invoice.setName("Name");
        invoice.setDoctor("Doctor");
        invoice.setAmount(1);
        Recipient recipient = new Recipient(invoice, "Name", RecipientHealth.EXCELENT);
        invoice.setRecipient(recipient);
    }

    @AfterEach
    public void tearDown() {
        reset(INVOICE_DAO);
    }

    @Test
    void getInvoices() {
        final List<Invoice> invoice = Collections.singletonList(this.invoice);
        when(INVOICE_DAO.findAll()).thenReturn(invoice);

        final List<Invoice> response = RESOURCES.target("/invoices")
                .request().get(new GenericType<List<Invoice>>() {
                });

        verify(INVOICE_DAO).findAll();
        assertThat(response).containsAll(invoice);
    }

    @Test
    void create() {
        when(INVOICE_DAO.create(any(Invoice.class))).thenReturn(invoice);
        final Response response = RESOURCES.target("/invoices")
                .request()
                .post(Entity.entity(invoice.toString(), MediaType.APPLICATION_FORM_URLENCODED));

        assertThat(response.getStatusInfo()).isEqualTo(Response.Status.OK);
        verify(INVOICE_DAO).create(personCaptor.capture());
        assertThat(personCaptor.getValue()).isEqualTo(invoice);
    }
}