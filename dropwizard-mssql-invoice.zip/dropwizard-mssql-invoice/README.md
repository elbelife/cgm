# Dropwizard Invoice App

How to start the Dropwizard Invoice App application
---

1. Run `mvn clean install` to build your application
1. Start application with `java -jar target/dropwizard-mssql-invoice-1.0-SNAPSHOT.jar server config.yml`
1. To check that your application is running enter url `http://localhost:8080`

The functions of Dropwizard Invoice App
---
 GET     /invoices (com.cgm.dropwizard.resources.InvoiceResource)
 POST    /invoices (com.cgm.dropwizard.resources.InvoiceResource)
 GET     /invoices/new (com.cgm.dropwizard.resources.InvoiceResource)
 PUT     /invoices/update/{id} (com.cgm.dropwizard.resources.InvoiceResource)
 DELETE  /invoices/{id} (com.cgm.dropwizard.resources.InvoiceResource)
 GET     /invoices/{id} (com.cgm.dropwizard.resources.InvoiceResource)

Health Check
---

To see your applications health enter url `http://localhost:8081/healthcheck`
